# Downloads
Download the latest builds.

## Release
| Windows | Linux | MacOS |
| --- | --- | --- |
| [MSVC 2017](https://storage.googleapis.com/shaderc/badges/build_link_windows_vs2017_release.html) | [clang](https://storage.googleapis.com/shaderc/badges/build_link_linux_clang_release.html) | [clang](https://storage.googleapis.com/shaderc/badges/build_link_macos_clang_release.html) |
| [MSVC 2015](https://storage.googleapis.com/shaderc/badges/build_link_windows_vs2015_release.html) | [gcc](https://storage.googleapis.com/shaderc/badges/build_link_linux_gcc_release.html) | |
| [MSVC 2013](https://storage.googleapis.com/shaderc/badges/build_link_windows_vs2013_release.html) | | |

## Debug
| Windows | Linux | MacOS |
| --- | --- | --- |
| [MSVC 2017](https://storage.googleapis.com/shaderc/badges/build_link_windows_vs2017_debug.html) | [clang](https://storage.googleapis.com/shaderc/badges/build_link_linux_clang_debug.html) | [clang](https://storage.googleapis.com/shaderc/badges/build_link_macos_clang_debug.html) |
| | [gcc](https://storage.googleapis.com/shaderc/badges/build_link_linux_gcc_debug.html) | |
